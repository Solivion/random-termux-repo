set (COMPIZ_BCOP_XSLT /data/data/com.termux/files/usr/share/compiz/xslt/bcop.xslt)
set (COMPIZ_GSETTINGS_SCHEMAS_XSLT /data/data/com.termux/files/usr/share/compiz/xslt/compiz_gsettings_schemas.xslt)
