#ifndef CONFIG_H
#define CONFIG_H

#define INSTALL_PREFIX "/data/data/com.termux/files/usr"
#define WAYFIRE_VERSION "0.12.0"
#define WAYFIRE_API_ABI_VERSION_STRING "20260801"
#define PLUGIN_PATH "/data/data/com.termux/files/usr/lib/wayfire"
#define PLUGIN_XML_DIR "/data/data/com.termux/files/usr/share/wayfire/metadata"
#define REL_LIBDIR "lib"
#define SYSCONFDIR "/data/data/com.termux/files/usr/etc"
#define WF_DEFAULT_CONFIG_BACKEND "/data/data/com.termux/files/usr/lib/wayfire/libdefault-config-backend.so"
#define BUILD_WITH_IMAGEIO
#define USE_GLES32
#define WF_HAS_XWAYLAND 1
#define WF_HAS_VULKANFX 0


#endif /* end of include guard: CONFIG_H */
