#ifndef CALL_GRAPH_WIDGET_H
#define CALL_GRAPH_WIDGET_H

#include "MemoryDockWidget.h"
#include "common/RefreshDeferrer.h"
#include "widgets/SimpleTextGraphView.h"

class MainWindow;
/**
 * @brief Graphview displaying either global or function callgraph.
 */
class CallGraphView : public SimpleTextGraphView
{
    Q_OBJECT
public:
    CallGraphView(CutterDockWidget *parent, MainWindow *main, bool global);
    void showExportDialog() override;
    void showAddress(RVA address);
    void refreshView() override;

protected:
    bool global; ///< is this a global or function callgraph
    RVA address = RVA_INVALID; ///< function address if this is not a global callgraph
    void loadCurrentGraph() override;
    void restoreCurrentBlock() override;

private:
    RefreshDeferrer refreshDeferrer;
    RVA lastLoadedAddress = RVA_INVALID;
};

class CallGraphWidget : public MemoryDockWidget
{
    Q_OBJECT

public:
    explicit CallGraphWidget(MainWindow *main, bool global);
    ~CallGraphWidget();

    QString getWidgetType() const;

protected:
    QString getWindowTitle() const override;

private:
    CallGraphView *graphView;
    bool global;

    void onSeekChanged(RVA address);
};

#endif // CALL_GRAPH_WIDGET_H
